import { WorkflowFile } from "maxun-core";

export const emptyWorkflow: WorkflowFile = { workflow: [] };
